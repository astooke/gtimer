
"""
Holds constants used across the package.
"""

UNASGN = 'UNASSIGNED'
